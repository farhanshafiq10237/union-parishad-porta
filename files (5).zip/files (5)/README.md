# 🇧🇩 ইউনিয়ন পরিষদ ডিজিটাল সেবা পোর্টাল
### Union Parishad Digital Service Portal

**Pure Node.js Backend — No npm dependencies required!**

---

## 🚀 চালু করার নিয়ম (How to Run)

```bash
node server.js
```
Then open: **http://localhost:3000**

---

## 📁 Project Structure

```
union-portal/
├── server.js              ← Main Express-style server (pure Node.js)
├── data/
│   ├── users.json         ← নাগরিক ডেটা
│   ├── admins.json        ← অ্যাডমিন ডেটা
│   ├── applications.json  ← আবেদন ডেটা
│   └── audit_log.json     ← অডিট লগ
└── public/
    ├── login.html         ← নাগরিক লগইন পেজ
    ├── register.html      ← নিবন্ধন পেজ (OTP)
    ├── dashboard.html     ← ব্যবহারকারী ড্যাশবোর্ড
    ├── admin.html         ← অ্যাডমিন লগইন + প্যানেল
    └── certificate.html   ← সনদ PDF পেজ
```

---

## 🔗 Pages

| URL | Description |
|-----|-------------|
| `/` or `/login` | নাগরিক লগইন |
| `/register` | নতুন নিবন্ধন |
| `/dashboard` | ব্যবহারকারী ড্যাশবোর্ড |
| `/admin` | অ্যাডমিন লগইন ও প্যানেল |
| `/certificate?id=APP-XXXX` | সনদ PDF |

---

## 🔌 REST API Endpoints

### Auth
- `POST /api/auth/register` — OTP পাঠান
- `POST /api/auth/verify-otp` — OTP যাচাই ও নিবন্ধন
- `POST /api/auth/login` — নাগরিক লগইন
- `POST /api/auth/admin-login` — অ্যাডমিন লগইন
- `POST /api/auth/logout` — লগআউট
- `GET /api/auth/me` — বর্তমান ব্যবহারকারী

### User
- `GET /api/user/profile` — প্রোফাইল দেখুন
- `PUT /api/user/profile` — প্রোফাইল আপডেট
- `GET /api/user/applications` — আমার আবেদন
- `POST /api/user/apply` — নতুন আবেদন

### Admin
- `GET /api/admin/dashboard` — ড্যাশবোর্ড ডেটা
- `GET /api/admin/applications` — সকল আবেদন
- `GET /api/admin/application/:id` — একটি আবেদন
- `POST /api/admin/approve` — অনুমোদন
- `POST /api/admin/reject` — বাতিল
- `GET /api/admin/users` — সকল ব্যবহারকারী
- `GET /api/admin/user/:id` — একজন ব্যবহারকারী
- `PUT /api/admin/edit-user` — ব্যবহারকারী সম্পাদনা
- `GET /api/admin/audit-log` — অডিট লগ
- `GET /api/admin/stats` — পরিসংখ্যান

---

## 👤 Demo User Accounts

| মোবাইল | পাসওয়ার্ড | নাম |
|--------|-----------|-----|
| 01712345678 | user123 | মোঃ রহিম উদ্দিন |
| 01812345678 | user123 | ফাতেমা বেগম |
| 01911223344 | user123 | মোঃ কামাল হোসেন |
| 01511234567 | user123 | মোঃ আনিসুর রহমান |

## 👮 Demo Admin Accounts

| Gov ID | পদবী | পাসওয়ার্ড |
|--------|------|-----------|
| GOV-1234-ABCD | chairman | admin123 |
| GOV-5678-EFGH | secretary | sec123 |
| GOV-9999-ZZZZ | monitor | mon123 |

---

## 🔐 Security Features
- Session-based authentication (HttpOnly cookies)
- HMAC-SHA256 password hashing
- Audit log for all admin actions
- Role-based access control (Chairman / Secretary / Monitor)
- OTP verification for registration (5 min expiry)
